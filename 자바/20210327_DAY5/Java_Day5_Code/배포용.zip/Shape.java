public class Shape {
	int x, y;
} 