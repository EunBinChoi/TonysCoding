// Comparable 인터페이스는 자바에서 기본적으로 제공하는 인터페이스

public interface Comparable {
// 이 객체가 다른 객체보다 크면 1, 같으면 0,  작으면 -1

}