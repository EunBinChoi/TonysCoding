public class Rectangle extends Shape {
	int width, height;
} 